﻿// Harmony usage based on
// https://github.com/roxxploxx/RimWorldModGuide/wiki/SHORTTUTORIAL%3A-Harmony

using HarmonyLib;
using RimWorld;
using System;
using System.Reflection;
using UnityEngine;
using Verse;

namespace TicksPerSecond
{
    [StaticConstructorOnStartup]
    internal static class TicksPerSecond
    {
        private static DateTime PrevTime;
        private static int PrevTicks;
        private static int TPSActual;

        static TicksPerSecond()
        {
            Harmony harmony = new Harmony("rimworld.sparr.tickspersecond");
            MethodInfo methodInfo1 = AccessTools.DeclaredMethod(typeof(GlobalControlsUtility), "DoTimespeedControls", (System.Type[])null, (System.Type[])null);
            HarmonyMethod harmonyMethod = new HarmonyMethod(typeof(TicksPerSecond).GetMethod("RimWorld_GlobalControlsUtility_DoTimespeedControls_Postfix"));
            MethodInfo methodInfo2 = methodInfo1;
            HarmonyMethod postfix = harmonyMethod;
            harmony.Patch((MethodBase)methodInfo2, (HarmonyMethod)null, postfix, (HarmonyMethod)null);
            TicksPerSecond.PrevTicks = -1;
            TicksPerSecond.TPSActual = 0;
        }

        public static void RimWorld_GlobalControlsUtility_DoTimespeedControls_Postfix(
          float leftX,
          float width,
          ref float curBaseY)
        {
            float tickRateMultiplier = Find.TickManager.TickRateMultiplier;
            int num = (int)Math.Round((double)tickRateMultiplier == 0.0 ? 0.0 : 60.0 * (double)tickRateMultiplier);
            if (TicksPerSecond.PrevTicks == -1)
            {
                TicksPerSecond.PrevTicks = GenTicks.TicksAbs;
                TicksPerSecond.PrevTime = DateTime.Now;
            }
            else
            {
                DateTime now = DateTime.Now;
                if (now.Second != TicksPerSecond.PrevTime.Second)
                {
                    TicksPerSecond.PrevTime = now;
                    TicksPerSecond.TPSActual = GenTicks.TicksAbs - TicksPerSecond.PrevTicks;
                    TicksPerSecond.PrevTicks = GenTicks.TicksAbs;
                }
            }
            Rect rect = new Rect(leftX - 20f, curBaseY - 26f, (float)((double)width + 20.0 - 7.0), 26f);
            Text.Anchor = TextAnchor.MiddleRight;
            string label = "TPS: " + TicksPerSecond.TPSActual.ToString() + "(" + num.ToString() + ")";
            Widgets.Label(rect, label);
            Text.Anchor = TextAnchor.UpperLeft;
            curBaseY -= 26f;
        }
    }
}